class AddisAdminToUser < ActiveRecord::Migration[6.0]
  def change
  end
end
