class AccueilController < ApplicationController

    def presentation
        #render html: "Page d'accueil"
    end
end